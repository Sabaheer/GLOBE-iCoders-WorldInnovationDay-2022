           package com.nopalyer.mpchart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class LineChartActivity extends AppCompatActivity {                                                                               

    //private static final String CHANNEL_ID = "Visualization" ;
    LineChart lineChart;
    Dialog myDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_chart);
        myDialog = new Dialog(this);

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LineChartActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        lineChart = findViewById(R.id.lineChart);
        LineDataSet lineDataSet = new LineDataSet(lineChartDataSet(),"CO level (ppm)");
        ArrayList<ILineDataSet> iLineDataSets = new ArrayList<>();
        iLineDataSets.add(lineDataSet);

        LineData lineData = new LineData(iLineDataSets);
        lineChart.setData(lineData);
        lineChart.invalidate();

        int maxCapacity = 35;
        LimitLine ll = new LimitLine(maxCapacity, "Max");
        ll.setLineWidth(2f);
        ll.setTextSize(12f);
        lineChart.getAxisLeft().addLimitLine(ll);

        //if you want set background color use below method
        //lineChart.setBackgroundColor(Color.RED);

        // set text if data are are not available
        lineChart.setNoDataText("Data not Available");

        //you can modify your line chart graph according to your requirement there are lots of method available in this library

        //now customize line chart

        lineDataSet.setColor(Color.BLUE);
        lineDataSet.setCircleColor(Color.TRANSPARENT);
        lineDataSet.setDrawCircles(true);
        lineDataSet.setDrawCircleHole(true);
        lineDataSet.setLineWidth(5);
        lineDataSet.setCircleRadius(10);
        lineDataSet.setCircleHoleRadius(10);
        lineDataSet.setValueTextSize(10);
        lineDataSet.setValueTextColor(Color.BLACK);

        Timer timer = new Timer();

        timer.schedule( new TimerTask() {
            public void run() {
                // do your work
                addEntry();
                //lineChart.notifyDataSetChanged();
                //lineChart.invalidate();
            }
        }, 0, 5*1000);

    }

    private void addEntry() {
        LineData data = lineChart.getData();
        if (data != null) {
            ILineDataSet set = data.getDataSetByIndex(0);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                int importance = NotificationManager.IMPORTANCE_HIGH;
                NotificationChannel channel = new NotificationChannel("Visualization", "Visualization", importance);
                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(channel);
            }

            float rand = (float) (Math.random() *40);

            float x = set.getEntryCount();

            data.addEntry(new Entry(x, rand), 0);
            data.notifyDataChanged();

            if (rand >= 35f){
                NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "Visualization")
                        .setSmallIcon(R.drawable.ic_danger)
                        .setContentTitle("DANGER!")
                        .setContentText(String.format("CO concentration level has reached %f ppm.", rand))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true);

                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(LineChartActivity.this);
                managerCompat.notify(1, builder.build());
            }

            // let the chart know it's data has changed
            lineChart.notifyDataSetChanged();
            // limit the number of visible entries
            lineChart.setVisibleXRangeMaximum(120);
            // chart.setVisibleYRange(30, AxisDependency.LEFT);
            // move to the latest entry
            lineChart.moveViewToX(data.getEntryCount());
            // this automatically refreshes the chart (calls invalidate())
            // chart.moveViewTo(data.getXValCount()-7, 55f,
            // AxisDependency.LEFT);
        }
    }


    public void ShowPopup(View v) {
        Button btnX;
        myDialog.setContentView(R.layout.popup);
        btnX = (Button) myDialog.findViewById(R.id.btnX);
        btnX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }


    private ArrayList<Entry> lineChartDataSet(){
        ArrayList<Entry> dataSet = new ArrayList<Entry>();

        dataSet.add(new Entry(0,40));
        dataSet.add(new Entry(1,10));
        dataSet.add(new Entry(2,15));
        dataSet.add(new Entry(3,12));
        dataSet.add(new Entry(4,20));
        dataSet.add(new Entry(5,40));
        dataSet.add(new Entry(6,23));
        dataSet.add(new Entry(7,34));
        dataSet.add(new Entry(8,22));
        dataSet.add(new Entry(9,10));
        dataSet.add(new Entry(10,5));
        /*dataSet.add(new Entry(11,16));
        dataSet.add(new Entry(12,18));
        dataSet.add(new Entry(13,20));
        dataSet.add(new Entry(14,23));
        dataSet.add(new Entry(15,24));
        dataSet.add(new Entry(16,26));
        dataSet.add(new Entry(17,29));
        dataSet.add(new Entry(18,31));
        dataSet.add(new Entry(19,32));
        dataSet.add(new Entry(20,32));
        dataSet.add(new Entry(21,36));
        dataSet.add(new Entry(22,23));
        dataSet.add(new Entry(23,14));
        dataSet.add(new Entry(24,10));*/
        return  dataSet;


    }
}
